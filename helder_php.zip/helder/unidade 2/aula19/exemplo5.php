<?php 

declare( strict_types=1); 
function fatorial(int $a) : int|bool {
    if($a < 0){
        return false;
    }

    $b = 1;
    for($i = 1; $i <= $a; $i++ ){
        $b = $b * $i;
    }
    return $b;
    
    
}

echo fatorial(5);