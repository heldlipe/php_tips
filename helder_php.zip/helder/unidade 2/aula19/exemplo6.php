<?php 

declare( strict_types=1); 

function media(int|float $a, int|float $b, int|float $c) : int|bool {
    $resultado = ($a + $b + $c) / 3;
    if($resultado < 6){
        return false;
    }elseif($resultado >= 6){
        return true;
    }
    
}

echo media(4, 8, 6);
echo "<hr>";
var_dump( media(6,5,6));
echo "<hr>";
var_dump( media(6,6,6));