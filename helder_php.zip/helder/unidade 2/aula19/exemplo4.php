<?php 
declare(strict_types=1);
function par(int $a) : bool
{
if($a % 2 == 0){
    return True;

}else{
    return False;
}
}
var_dump( par(30));
echo "<hr>";
var_dump( par(31));