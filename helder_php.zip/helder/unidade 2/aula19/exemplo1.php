<?php


function somar($a, $b)
{#corpo da função
    $resultado = $a + $b;
    return $resultado; #retorno de um valor
}

echo somar(10 , 5); #chamada ou invocação da função.