<?php 

function comparar_valor(int $a, int $b) : int
{
if($a>$b){
    return $a;
}elseif($a<$b){
    return $b;
}else{
    return "São iguais";
}
}
echo comparar_valor(28, 210);