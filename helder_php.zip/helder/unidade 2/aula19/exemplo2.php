<?php 
 
 function desconto($a, $b){
    $c = $b / 100;
    $resultado = $a * $c;
    $valorfinal = $a - $resultado;
    return $valorfinal;
 }
 
 echo desconto(10, 17);