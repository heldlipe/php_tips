<?php

function parouimpar($num){
    if($num % 2 == 00){
        return "par";
    }
    return "impar";
}

echo parouimpar(5)."<br>";
echo parouimpar(14)."<br>";