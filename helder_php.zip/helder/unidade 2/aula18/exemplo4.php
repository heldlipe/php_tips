<?php


function multiplicar(int $a, int $b) :int 
{
        $resultado = $a * $b;
        return $resultado;
}

echo multiplicar(5, 8)."<br>";
echo multiplicar(5.8, 2)."<br>";