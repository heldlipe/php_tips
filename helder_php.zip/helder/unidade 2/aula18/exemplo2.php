
<?php
function dobro($a){
    $resultado = $a * 2;
    return $resultado;
}


echo"o dobro do número é". dobro(10);