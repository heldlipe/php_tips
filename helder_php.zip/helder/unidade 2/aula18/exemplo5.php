<?php
declare (strict_types=1);

function pessoa(string $nome, int $anonasc) :string 
{
    $idade = 2024 - $anonasc;
    return "Seu nome é: $nome sua idade é: $idade"; 
}

echo pessoa("Helder", 2004)."<br>";
echo pessoa("Maria de Lourdes", 1945)."<br>";