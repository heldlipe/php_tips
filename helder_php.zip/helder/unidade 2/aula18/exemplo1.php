<?php

function soma($a,$b){
    $resultado = $a + $b;
    return $resultado;
}

$retorno = soma(10,5);
echo $retorno;