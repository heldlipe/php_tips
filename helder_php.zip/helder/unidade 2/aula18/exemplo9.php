<?php

declare (strict_types=1);

function preco(float $prec, int $qtd = 1, float $desc = 0 ) : int | float{

    return $prec * $qtd - $desc ;
}
 echo preco(2.6, 4)."<br>";
 echo preco(10, 3, 2)."<br>";
 echo preco(12.7, 2, 1.5)."<br>";
 echo preco(12.7)."<br>";