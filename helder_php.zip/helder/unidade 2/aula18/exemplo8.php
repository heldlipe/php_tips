<?php

declare (strict_types=1);

function tag(string $texto, string $tag = "p") :void 
{
    
    echo "<$tag> $texto </$tag>"; 
}
tag("bgfrbnkjefgnkjergnkjegkeg", "h1");
tag("parametrosd");