<?php 

declare (strict_types=1);

function calc(int $a, int $b):int|float{
    $result = $a / $b;
    return $result;
}

echo calc(3,4);