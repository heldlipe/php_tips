<?php 
declare(strict_types = 1);

function calcularMedia(array $notas) : float
{
    $soma = 0;
    foreach($notas as $nota){
        $soma = $soma + $nota;
    }
    $quantidade = count($notas);
    $media = $soma / $quantidade;
    return $media;
}
echo calcularMedia( [8.5 , 9.2 , 8.8, 5.4, 7.5] );