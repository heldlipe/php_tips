<?php

$minhafuncao = function(string $nome){
echo "boa tarde, $nome <br>";

};
 $mensagem = "Olá,";

$minhafuncao2 = function(string $nome) use($mensagem){
    echo "$mensagem $nome <br>";
    
    };

$minhafuncao ( "helder"). "<br>";
$minhafuncao2 ( "helder");