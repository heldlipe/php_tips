<?php

declare(strict_types = 1);


function imprimeNomes(string ...$nomes) :void {
    foreach($nomes as $nome){
        echo $nome . "<br>";
    }
}
echo imprimeNomes("Thiago", "Marcia", "João");