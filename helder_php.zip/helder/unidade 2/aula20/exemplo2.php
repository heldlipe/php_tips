<?php
declare (strict_types = 1);

function calTotal(float|int $valor, int $quant =1, int $desc =0) : float
{
$total = $valor * $quant;
$desconto = $total * ($desc / 100);
$total = $total - $desconto;
return $total;
}
echo calTotal(100,2,10)."<br>";
echo calTotal(100)."<br>";
echo calTotal(100,2)."<br>";
echo calTotal(100,1,25)."<br>";

echo calTotal(desc:25, valor:100)."<br>";
