<?php
 
 declare (strict_types = 1);

function dobraValor(int & $num): void 
{
    $num = $num * $num;
}
$a = 2;
dobraValor($a);
echo  $a ."<br>";
dobraValor($a);
echo  $a ."<br>";
