<?php

declare(strict_types=1);

function incrementaValor(int $valor) :void {
    $valor++;

}
function incrementaValor2(int & $valor) :void {
    $valor++;

}

$num1=5;
incrementaValor2($num1);
echo $num1;