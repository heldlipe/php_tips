<?php

$dados =   ["Nome"=>"Helder", 
            "Idade"=>19, 
            "Altura"=>"1.8m",
            "Peso"=>"70kg"];

            foreach($dados as $indice =>$valor){
                echo"$indice: $valor <hr>";
            }