<?php

$carros = ["Fusca", "Gol", "fiesta", "uno"];
$carros [] = "hilux";

$quantidade = count($carros);

for($i = 0; $i<$quantidade; $i++){
    echo"<li> $carros[$i] </li>";
}