<?php
$carros = ["Fusca", "Gol", "fiesta", "uno"];



$carros[] = "voyage"; // adiciona ao final
$carros[] = "toro";
$carros[10] = "saveiro";
$carros[] = "strada";
$carros[0] = "corolla";

echo"<pre>";
print_r($carros);
echo"</pre>";