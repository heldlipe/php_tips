<?php

$idades = [18,19,20,12,15,17,10,11,9];
$soma= 0;
$quantidade = count($idades);
foreach($idades as $i){
    $soma += $i;
}
$media = $soma/$quantidade;
echo"A média das idades do array é:". number_format($media,1);