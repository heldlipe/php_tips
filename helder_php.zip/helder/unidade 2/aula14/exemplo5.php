<?php

$carros = ["Fusca", "Gol", "fiesta", "uno"];
$carros [] = "hilux";
$carros [10] = "S10";

foreach ($carros as $indice=> $carro) {
    echo"<li> $carro </li>";
}


