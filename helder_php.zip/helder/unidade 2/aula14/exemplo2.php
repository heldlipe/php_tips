<?php

$idades = [18,19,20,12,15,17,10,11,9];
Echo "<pre>";
print_r($idades); // indice e valor
var_dump($idades); //tamanho, inidice, valor e tipo
Echo "</pre>";