<?php

$idades = [18,19,20,12,15,17,10,11,9];
$cores = array("vermelho", "azul", "verde","rosa");

echo $cores[0]."<br>";
echo $cores[3]."<br>";
echo $idades[1]."<br>";
echo $idades[8]."<br>";