<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="exemplo8.php" method="post"> 
        <label>Nome: 
            <input type="text" name="nome">
        </label>
        <br>
        <br>
        <br>
        <label>idade: 
            <input type="number" name="idade">
        </label>
        <br>
       <br>
       <button>Enviar</button>
    </form>
    <div>
       <?php

        if($_SERVER["REQUEST_METHOD"]=="POST"){
            foreach($_POST as $campo => $valor){
                echo"<li> $campo: $valor </li>";
            }
        }

       ?>
    </div>
</body>
</html>