<?php

$carros = [
    ["fusca", "volks", 1978],
    ["montana", "chevrolet", 2014],
    ["uno", "fiat", 2003]
];

echo $carros[1][1]."<br>"; // primerio a linha, segunda a coluna.