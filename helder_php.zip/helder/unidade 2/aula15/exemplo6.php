<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="receber1.php" method="get">
        <label> Nome:
            <input type="text" name ="nome">
        </label>
        <br>
        <label> Nota:
            <input type="number" name ="nota[]" step="0.1">
        </label>
        <br>
        <label> Nota:
            <input type="number" name ="nota[]" step="0.1">
        </label>
        <br>
        <label> Nota:
            <input type="number" name ="nota[]" step="0.1">
        </label>
        <br>
        <button> Enviar </button>
       
    </form>
</body>
</html>