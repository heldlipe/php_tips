<?php

$altura = [1.65 , 1.83 , 1.55 , 1.94, 1.88];
$soma = 0;
$quantidade = count($altura); // recupera a qntd de elementos


foreach($altura as $indice => $alt){
    $indice= $indice + 1;
    echo "Altura $indice: $alt <br>";
    $soma += $alt; // $soma + $altura
}

$media = $soma / $quantidade ;

Echo " a media foi de $media metro";