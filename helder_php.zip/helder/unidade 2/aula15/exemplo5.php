<?php

$carro = ["marca"=>"chevrolet", "nome" => "montana", "ano" => 2014, "motor" => 1.4];
//echo $carro["ano"];

foreach ($carro as $indice=>$car){

    echo "$indice : $car ;<br>";
}