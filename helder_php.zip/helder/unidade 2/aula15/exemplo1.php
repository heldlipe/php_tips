<?php 
$nomes = ["joão", "Pedro", "Maria", "Joana"];
$nomes[]= "Mariana"; // acrescente no final.
echo $nomes[4]."<br>";
$nomes[4]= "Helder"; // vai ficar fixa nessa posição '4'.
echo $nomes[4]."<br>";
$nomes[1]= "Maycola"; 
echo $nomes[1]."<br>";