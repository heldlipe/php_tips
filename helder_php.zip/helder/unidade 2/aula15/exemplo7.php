<?php 
$aluno1 = ["João", 8.7 , 9.6, 4.6];
$aluno2 = ["Maria", 9.7 , 9.2, 7.6];
$aluno3 = ["Helder", 7.7 , 9.6, 10];

#array multidimensional, tem outros arrays como elementos;

$alunos = [$aluno1,$aluno2,$aluno3];


 echo "<pre>"; 
 var_dump($alunos);