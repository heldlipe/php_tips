<?php

$nome = $_GET["nome"]?? null;
$nota = $_GET["nota"]?? null;

echo $nome."<br>";
foreach($nota as $n){
    echo "Nota: $n <br>";
}