<?php

$cores = ["Verde", "Amarelo", "Rosa", "Azul"];
$carros = ["fusca", "Strada", "gol", "chevete"];

foreach($cores as $cor){
    echo $cor."<br>";
}

echo "<br>";

foreach($carros as $carro){
    echo $carro."<br>";
}