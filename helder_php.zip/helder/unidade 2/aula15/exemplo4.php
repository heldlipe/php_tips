<?php
// Arrays associativos são arrays de indices textuais.
    //   0           1          2            3      4   5
$aluno =["João", "2º serie", "Informática", 5.8 , 6.8 ,0.8 ];

echo $aluno[2]."<br>";

$aluno2 = ["nome"=>"João" , "serie"=>"2º serie", "disciplina"=>"Informática", "nota1" => 5.8 ,"nota2" => 6.8 , "nota3" =>0.8 ];

echo $aluno2["disciplina"]."<br>";