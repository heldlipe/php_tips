<?php
function multiplo3(int $a) :bool {
if($a % 3 == 0){
return True;
}else{ 
    return False;
}
}
$resultado = multiplo3(15);
var_dump($resultado);