<?php

$numeros = [10,9,8,7,6,5,4];
foreach($numeros as $n){
    echo $n . "<br>";
}

$nomes = ["João", "Maria", "José"];
foreach($nomes as $indice => $valor){
    echo "$indice - $valor <br>";
}

$alunos = ["11115884-56" => "João", "21545944-58" => "Maria"];
foreach($alunos as $cpf => $nome){
    echo "Nome: $nome - CPF: $cpf <br>";
}

$produtos = ["tv" => "523,00", "ps4" => "458,30", "smartphone" => "389,90"];
foreach($produtos as $nome => $valor){
    echo "Nome: $nome - Preço: $valor <br>";
}