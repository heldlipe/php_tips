<?php

function somar($a, $b = 5){
    $resultado = $a + $b;
    echo $resultado;
}
somar(5,5);
somar(5);
