<?php

$produtos = [
    ["produto" => "televisão", "preco" => 2499.5 , "marca" => "Samsung"], 
    ["produto" => "Ar condicionado", "preco" => 3215.8 , "marca" => "Gree"],
    ["produto" => "Notebook", "preco" => 1899.5 , "marca" => "Asus"],
    ["produto" => "Maquina de lavar", "preco" => 2999.99, "marca" => "LG"]
];

foreach($produtos as $produto){
    foreach($produto as $valor){
        echo $valor . "<br>";
    }
    echo"<hr>";
}