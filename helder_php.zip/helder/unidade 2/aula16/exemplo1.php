<?php

$produtos = [
    ["televisão", 2499.5 , "Samsung"], 
    ["Ar condicionado", 3215.8 , "Gree"],
    ["Notebook", 1899.5 , "Asus"]
];

echo $produtos[2][2] . "<br>";

$produtos = [
    ["produto" => "televisão", "preco" => 2499.5 , "marca" => "Samsung"], 
    ["produto" => "Ar condicionado", "preco" => 3215.8 , "marca" => "Gree"],
    ["produto" => "Notebook", "preco" => 1899.5 , "marca" => "Asus"]
];

echo "<hr>";
echo $produtos[1]["produto"]."<br>";
echo $produtos[2]["marca"]."<br>";
echo $produtos[0]["preco"]."<br>";

$produtos = [
    ["produto" => "televisão", "preco" => 2499.5 , "marca" => "Samsung"], 
    ["produto" => "Ar condicionado", "preco" => 3215.8 , "marca" => "Gree"],
    ["produto" => "Notebook", "preco" => 1899.5 , "marca" => "Asus"]
];

$produtos[] = ["produto" => "Maquina de lavar", "preco" => 2999.99, "marca" => "LG"];

echo "<hr>";
echo $produtos[3]["produto"]."<br>"; 

$produtos[3]["produto"] = "Lava e Seca";

echo "<hr>";
echo $produtos[3]["produto"]."<br>"; 
echo "<hr>";
foreach($produtos as $produto){
    echo $produto["produto"] . "<br>";
    echo $produto["preco"] . "<br>";
    echo "<hr>";

}