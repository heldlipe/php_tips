<?php

$funcionarios =[ 
["nome" => "Lyvia", "cargo" => "gerente adm", "salario" => 5654.00, "curriculo" => "+10 anos em gerencia", "foto" => "https://randomuser.me/api/portraits/women/25.jpg"],
["nome" => "Joana", "cargo" => "porteira", "salario" => 2254.00, "curriculo" => "+5 anos de experiência", "foto" => "https://randomuser.me/api/portraits/women/23.jpg"],
["nome" => "Helder", "cargo" => "CEO", "salario" => 15654.00, "curriculo" => "+20 anos em administração" ,"foto" => "https://randomuser.me/api/portraits/men/22.jpg"]
];



?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Funcionários</title>
    <link href = "estilo.css" rel="stylesheet">
</head>
<body>
        <header>
            <h1> Lista de Funcionários</h1>
        </header>
        <main>
        <?php
        foreach($funcionarios as $funcionario){
            echo"<div class='box'>";
            echo "<img src= '{$funcionario['foto']}'><br>";
            echo "Nome:" .$funcionario['nome']."<br>";
            echo "Cargo:" .$funcionario['cargo']."<br>";
            echo "Salario: {$funcionario['salario']}<br>";
            echo "Curriculo: {$funcionario['curriculo']}<br>";
            echo"</div>";
        
            //foreach($funcionario as $valor){
              //  echo $valor . "<br>";
            //}
            //echo"<hr>";
        }
        ?>
        </main>

</body>
</html>