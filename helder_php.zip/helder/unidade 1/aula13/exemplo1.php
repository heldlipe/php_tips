<?php 


$inicio = $_GET['inicio'] ?? 0;
$fim = $_GET['fim'] ?? 10;

//1- inicialização; 2- condição; 3- modificação;

for($a = $inicio; $a <= $fim; $a++ )
{
    echo $a . "<br>";
}
