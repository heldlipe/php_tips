<?php
$cidadeA = 30000;
$cidadeB = 55000;
$taxaA = 0.08;
$taxaB = 0.02;
$anos = 0;


while($cidadeA <= $cidadeB){
    $cidadeA = $cidadeA + ($cidadeA * $taxaA);
    $cidadeB = $cidadeB + ($cidadeB * $taxaB);
    $anos++;
}

echo "A cidade A ultrapassará a cidade B em $anos anos";