<?php 

// inicialização
$divida = 100;
$taxa = 0.07;
$abatimento = 12;
$pago = 0;
$mes = 0;

//condição
while($divida >= $pago){
    #modificação
    $divida = $divida - $abatimento;
    $divida = $divida + ($divida * $taxa);
    $mes ++;

    echo "Mês: $mes - Valor da dívida: R$ $divida <hr>";
}

echo"serão $mes meses";