<?php

//do.... while

$i = 100;
/*


while ($i>=10){
    echo $i."<br>";
    $i--;
}
echo "<hr>";     


*/
do{
    echo $i."<br>";
    $i--;
}while($i>10);