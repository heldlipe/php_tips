<?php


$numero = 10;
$fatorial = 1;
$contador = $numero;

do{
    $fatorial = $fatorial * $contador;
    $contador --;
}while($contador > 0);
echo "o fatorial de $numero é $fatorial";