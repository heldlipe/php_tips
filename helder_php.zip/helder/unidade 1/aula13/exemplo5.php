<?php

$inicial = $_GET['inicial'] ?? 10;
$final = $_GET['final'] ?? 0;


while ( $inicial > $final ){
    $result = $inicial;
    echo "$result; <br>" ;
    $inicial = $inicial - 1;
    
}
echo $final."." ;