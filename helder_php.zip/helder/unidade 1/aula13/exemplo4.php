<?php
// inicialização
$inicio = 1;
$fim = 200;
$soma = 0;

#condição
while ($inicio <= $fim){

    $soma = $soma + $inicio;
//modificação
    $inicio++;
}

echo  "A soma dos numeros de 1 a 200 é: $soma";
