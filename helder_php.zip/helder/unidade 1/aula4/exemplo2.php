<?php      
    $nome = isset($_GET["nome"]) ? $_GET["nome"] : " defina um nome, volte a página" ;
    $email = $_GET["email"] ?? " ";

    echo "<h2> Nome: $nome  <hr>  Email: $email </h2>";
?> 