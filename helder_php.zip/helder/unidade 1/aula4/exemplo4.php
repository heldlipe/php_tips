<?php 
    $apelido = $_POST['apelido'] ?? "";
    $nascimento = $_POST['nascimento'] ?? "";
    $sexo = $_POST['sexo'] ?? "";
    $turma = $_POST['turma'] ?? "";
    
    
    echo "<h2> apelido: $apelido  | data de nascimento: $nascimento <hr>  Sexo: $sexo | Turma: $turma  </h2>";
?>