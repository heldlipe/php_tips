<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulários</title>
</head>
<body>
    <h1>  Formularios html</h1>
    <Form action="exemplo4.php" method="post">
        <label>
            Apelido:
            <input type= "text" name="apelido">
        </label>
        <label>
            data de nascimento:
            <input type= "date" name="nascimento">
        </label>

      <fieldset>
        <legend> Sexo:</legend>
        <label>
            <input type= "radio" name="sexo" value="masculino">
            masculino
        </label>
        <hr>
        <label>
            <input type= "radio" name="sexo" value="feminino">
            feminino
        </label>
      </fieldset>
        <br>

        <label>
            Turma:
            <select name="turma">
                <option value=""> </option>
                <option value="Informática"> Informática </option>
                <option value="Edificações"> Edificações </option>
                <option value="Mineração"> Mineração </option>
            </select> 
        </label>
        
        <br><br>

        <button> Enviar </button>

    </form>
</body>
</html>