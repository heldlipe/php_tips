<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulários</title>
</head>
<body>
    <h1> Formularios HTML</h1>
    <form action="exemplo2.php" method="get" >
        <!--   
            action -> atributo responsavel por inidicar qual arquivo irá receber os dados desse formulário 
            method -> atributo responsável por indicar qual método será utilizado neste envio de dados.        
            GET (método para recuperar os dados, utilizando a barra de pesquisa) 
            POST ()
        --> 
        <label>  
            Nome:
            <input type="text"  name="nome" >
        </label>
        <label> 
            Email:
            <input type="email" name="email">
            
        </label>
        <button>ENVIAR</button>

    </form>
</body>
</html>