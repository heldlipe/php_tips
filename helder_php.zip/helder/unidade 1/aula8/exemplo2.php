<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>Formulário</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
	<header>
		<h1>Estrutura de Repetição</h1>
	</header>
	<div class= "container">
		<div class="box resposta">
		<?php
            #estrutura de repetição 
            /* A aprtir de uma condição a estrutura de repetição repete a execução de um bloco de código definido mainha 
            1- inicialização, onde uma variavel controle irá receber o seu valor incial
            2-condiçaõ: onde essa variavel controle é testada para saber se a repetição irá ou não continuar
            3-modificaçaõ: onde a variavel de controle é modificada para que em um determinado momento ela deixe de atender a condiçaõ de repetição.*/
            for($controle = 0; ; $controle++){
                echo "<h3>$controle ;</h3>";
            } 
        ?>         
		</div>
	</div>
</body>
</html>