<!DOCTYPE html>
<html>
<head>
	<title>Formulário com PHP</title>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,700" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
	<div class="container box">
	    <?php
            $altura = $_POST['altura'];
            $peso = $_POST['peso'];
            $sexo = $_POST['sexo'];
            $idade = $_POST['idade'];

            $imc = $peso / ($altura * $altura);
            echo "<h2> o seu IMC é de:".number_format($imc,2)."</h2>" ;
            if($imc < 18.5){
                echo "<div class =' alerta-amarelo' >Magreza</div>";
            }else if($imc >= 18.5 and $imc < 25){
                echo "<div class =' alerta-verde' >Normal</div";
            }else if($imc >= 25 and $imc < 30){
                echo "<div class = ' alerta-amarelo' >Sobrepeso</div";
            }else if($imc >= 30 and $imc < 35){
                echo "<div class =' alerta-vermelho' >Obesidade grau I</div";
            }else if($imc >= 35 and $imc < 40){
                echo "<div class =' alerta-vermelho' >Obesidade grau II";
            }else{ 
                echo "<div class =' alerta-vermelho' >Obesidade grau III";
            }
        ?>
	</div>
</body>
</html>
