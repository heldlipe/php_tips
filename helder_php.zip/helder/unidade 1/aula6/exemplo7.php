<?php

$lados = $_GET["lados"] ?? "";

switch($lados){
    case 3 :
        echo"A forma geométrica é um Triângulo, pois têm $lados lados";
    break;
    case 4 :
        echo"A forma geométrica é um Quadrado, pois têm $lados lados";
    break;
    case 5 :
        echo"A forma geométrica é um Pentagono, pois têm $lados lados";
    break;
    case 6 : 
        echo"A forma geométrica é um Hexagono, pois têm $lados lados";
    break;
}