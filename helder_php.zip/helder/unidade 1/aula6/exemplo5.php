<?php

$lados = $_GET["lados"] ?? "";
if($lados==3){
    echo"A forma geométrica é um Triângulo, pois têm $lados lados";
}elseif($lados==4){
    echo"A forma geométrica é um Quadrado, pois têm $lados lados";
}elseif($lados==5){
    echo"A forma geométrica é um Pentagono, pois têm $lados lados";
}elseif($lados==6){
    echo"A forma geométrica é um Hexagono, pois têm $lados lados";
}else{
    echo"Não está cadastrada essa forma geométrica, busque em um 
    livro de geometria";
}

echo"<a href='exemplo4.php'>Voltar</a>";