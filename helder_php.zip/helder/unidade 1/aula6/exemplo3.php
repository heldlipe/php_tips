<?php
$idade = 65 ;
if($idade < 16 and $idade > 0 ){
    echo"Não pode votar, pois tem $idade anos de idade.";
}elseif(($idade >= 16 and $idade < 18) or $idade >= 65 ){
    echo"Voto Facultativo, pois tem $idade anos de idade.";
}elseif($idade >=18 and $idade < 65  ){  
    echo"Voto obrigatório , pois tem $idade anos de idade.";
}else{
    echo" sua idade é: $idade ; com mais de 16 anos até 18 é facultativo, 
    com 65 anos também. De 18 anos a 65 anos é obrigatório e menor de 16 anos não pode votar";
}
