<?php

$salario = 1400;
if($salario>=1400){
    echo"tem que declarar imposto de renda || $salario";
}else{
    echo"NÃO tem que declarar imposto de renda || $salario";
}