<?php $salario = 4200;
if($salario < 2300 ){
    echo"Não paga o imposto";
}elseif($salario >= 2300 and $salario < 3500 ){
    echo"paga 14% de R$$salario,00";
}elseif($salario >=3500 and $salario < 4400  ){  
    echo"paga 22% de R$$salario,00";
}else{
    echo"paga 27% de R$$salario,00";
}
