<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Condições</title>
</head>
<body>
    <form action="exemplo7.php" method="get">
        <h1>Descubra a forma geométrica</h1>
        <label>
            Quantidade de lados:
            <input type="number" name="lados" min="3" max="6" value="3">
        </label>
        <button>Enviar</button>
    </form>
</body>
</html>