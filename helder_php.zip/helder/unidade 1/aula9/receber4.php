<?php

$numero1 = $_GET['numero1'];
$numero2 = $_GET['numero2'];
$soma = $numero1 + $numero2 ;

if($soma > 20){
 $total= $soma + 8;
}elseif($soma<=20){
    $total = $soma - 5;
}else{
    $total = 0;
}

echo"O numero total é : $total";