<?php
    #Definir uma constante, ou seja um espaço de memoria que não pode ser modificado durante a execução.
    define('PI',3.141592);

    $raio = $_GET['raio'] ?? 0;

    $perimetro = 2 * PI * $raio;
    $area = PI * $raio**2; # PI * ($raio * $raio)

    echo "O Perímetro é : $perimetro e; <br> a área do círculo é: $area . <br>";
    echo "<a href='questao1.php'>Voltar</a>";