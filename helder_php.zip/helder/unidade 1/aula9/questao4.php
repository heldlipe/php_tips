<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action='receber4.php' method='GET'>
        <label> Numero 1
            <input type='number' name='numero1' step='0.1' >
        </label>
        <label> Numero 2
            <input type='number' name='numero2' step='0.1' >
        </label>
        <button> ENVIAR </button>
    </form>
</body>
</html>