<?php 
 
$valor = $_POST['valor'] ?? 0;

$valortotal = $valor * 1.15; # valor + 15%
$valorparcela = $valortotal / 10;

echo"O valor total parcelado é: $valortotal; <br>
o valor de cada parcela é: $valorparcela; <br>
o valor inicial era: $valor.";