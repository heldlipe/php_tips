<?php

$altura = $_POST['altura'] ?? 0;
$sexo = $_POST['sexo'] ?? '';
if ($sexo == 'M'){
    $pesoideal = ($altura * 72.7) - 58;
    $sexotexto = "Masculino";
    
}elseif($sexo == 'F') {
    $pesoideal = ($altura*62.1) - 44.7;
    $sexotexto = "Feminino";
}else{
    $pesoideal = 0;
    $sexotexto = "não foi informado";
}

echo "a altura é : $altura; seu sexo é: $sexotexto. E tem o peso ideal de : $pesoideal kg";
