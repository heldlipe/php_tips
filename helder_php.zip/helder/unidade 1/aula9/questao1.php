<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exercicios de PHP</title>
</head>
<body>
    

<h1> Questão 1</h1>
  <form action="receber1.php" method="GET">
    <label> raio do circulo: 
        <input type="number" name="raio">
    </label>
    <button> Calcular</button>
  </form>
</body>
</html>