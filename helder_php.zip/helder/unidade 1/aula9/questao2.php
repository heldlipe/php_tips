<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Compras</title>
</head>
<body>
    <h2>Questão 2</h2>
    <form action='receber2.php' method="POST">
        <label> Preço do produto:
            <input type="number" name="valor" step="0.01">
        </label>
        <button>ver preço total e parcelas</button>
    </form>
</body>
</html>