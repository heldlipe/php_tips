<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Atividade 2</title>
</head>
<body>
    <form action="receber2.php" method="post">
        <label> Número 1
            <input type="number" name="num1" step="0.1">
        </label> 
            <br>
        <label> Número 2
            <input type="number" name="num2" step="0.1">
        </label> 
            <br>
        <label> Número 3
            <input type="number" name="num3" step="0.1">
        </label> 
            <br>
        <button>Enviar</button>
    </form>
</body>
</html>