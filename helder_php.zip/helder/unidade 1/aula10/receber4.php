<?php

/* $numero1 = $_POST['num1'] ?? 0;
$numero2 = $_POST['num2'] ?? 0;
$numero3 = $_POST['num3'] ?? 0;

$somatri = $numero1 + $numero2 ;
 
if($somatri>$numero3){
    echo"HÁ A POSSIBILIDADE DE FORMARMOS UM TRIÂNGULO";
}else{
    echo"Não se pode ter um triângulo";
}



        echo "<br> <a href = 'exemplo2.php'> voltar </a>"; */ 
    
$numero1 = $_POST['num1'] ?? 0;
$numero2 = $_POST['num2'] ?? 0;
$numero3 = $_POST['num3'] ?? 0;


if($numero1>=$numero2 and $numero1>=$numero3){
    $soma = $numero2 + $numero3;
    if($soma>$numero1){
        echo"Poderemos ter um triangulo";
    }else{
        echo"Não existe a possibilidade de ter um triangulo";
    }

}elseif($numero2>=$numero1 and $numero2>=$numero3){
    $soma = $numero1 + $numero3;
    if($soma>$numero2){
        echo"Poderemos ter um triangulo";
    }else{
        echo"Não existe a possibilidade de ter um triangulo";
    }

}elseif($numero3>=$numero1 and $numero3>=$numero2){
    $soma = $numero2 + $numero1;
    if($soma>$numero3){
        echo"Poderemos ter um triangulo";
    }else{
        echo"Não existe a possibilidade de ter um triangulo";
    }

}else{
    echo"Não há como fazer calculos";
}
        

