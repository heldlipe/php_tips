<?php

$number = $_GET["numero"] ?? 0;

if($number%2 == 0){
    echo" O Numero divide por 2. <br>";
}
if($number%5 == 0){
    echo" O Numero divide por 5. <br>";
}
if($number%10 == 0){
    echo" O Numero divide por 10. <br>";
}

if($number%2 != 0 and $number%5 != 0 and $number%10 != 0){
    echo"Não é divisel por 2, nem por 5 e nem por 10. <br>";
}else{
    if($number%2 != 0 ){
        echo"Não é divisel por 2. <br>";
    }
    if($number%5 != 0){
        echo"Não é divisel por 5. <br>";
    }
    if($number%10 != 0){
        echo"Não é divisel por 10.<br>";
    }
}



