<?php

$numero1 = $_POST['num1'] ?? 0;
$numero2 = $_POST['num2'] ?? 0;
$numero3 = $_POST['num3'] ?? 0;

if($numero1>$numero2 && $numero1>$numero3){
    if($numero2>$numero3){
        echo"a ordem decrescente é: $numero1 , $numero2 e $numero3";
    }elseif($numero3>$numero2){
        echo"a ordem decrescente é: $numero1 , $numero3 e $numero2";
    }else{
        echo"Não existe uma ordem decrescente";
    }

}elseif($numero2>$numero1 && $numero2>$numero3){
    if($numero1>$numero3){
        echo"a ordem decrescente é: $numero2 , $numero1 e $numero3";
    }elseif($numero3>$numero1){
        echo"a ordem decrescente é: $numero2 , $numero3 e $numero1";
    }else{
        echo"Não existe uma ordem decrescente";
    }

}elseif($numero3>$numero1 && $numero3>$numero2){
    if($numero2>$numero1){
        echo"a ordem decrescente é: $numero3 , $numero2 e $numero1";
    }elseif($numero1>$numero2){
        echo"a ordem decrescente é: $numero3 , $numero1 e $numero2";
    }else{
        echo"Não existe uma ordem decrescente";
    }

}else{
    echo"Não existe uma ordem decrescente";
}
        echo "<br> <a href = 'exemplo2.php'> voltar </a>";