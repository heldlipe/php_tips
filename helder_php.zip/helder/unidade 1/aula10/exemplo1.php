<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Revisando PHP</title>
</head>
<body>
    <h1>Atividade 1!</h1>
    <form action="receber1.php" method="get">
        <label> Número 1:
            <input type="number" name="num1" value="1" step="0.01">
        </label>
            <br>
        <label> Número 2:
            <input type="number" name="num2" step="0.01">
        </label>
            <br>
        <button>Enviar</button>
    </form>
</body>
</html>