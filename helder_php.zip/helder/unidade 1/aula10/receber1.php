<?php
$numero1 = $_GET["num1"] ?? 0;
$numero2 = $_GET["num2"] ?? 0;

if($numero1 > $numero2){
    echo"o numero 1: $numero1 é maior que o 2: $numero2";
}elseif($numero2 > $numero1){
    echo"o numero 2 : $numero2 é maior que o 1: $numero1";
}else{
    echo"São iguais os números 1 e 2!";
}