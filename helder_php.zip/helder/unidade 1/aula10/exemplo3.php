<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="receber3.php" method="get">
        <label> Número 
            <input type="number" name="numero" step="1">
        </label>
        <br>
        <button>Enviar</button>
    </form>
</body>
</html>