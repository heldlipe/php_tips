<?php 

//for(inicialização, condição, atualçização)
for($contador = 1; $contador <= 10; $contador ++  )  { /* $contador = $contador + 1 */
    echo "$contador <br>";
}