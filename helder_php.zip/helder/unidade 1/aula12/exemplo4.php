<?php 




for($contador = 10; $contador <= 100; $contador += 10) {
    echo "$contador<br>" ;
}