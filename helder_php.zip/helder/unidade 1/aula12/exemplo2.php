<?php


/* Receba atraves do met. GET um código HTTP e mostre atraves da estrutura match o seu significado correspondente*/
/* 200 -> ok
400 e 404 -> not found
500 e 501 -> server error*/

$http = $_GET['http'] ?? 0;
$http = (int) $http; //conversão de tipo p/inteiro

echo match ($http) {
    200 => "ok" ,
    400,404 => "not found",
    500,501 => "Server error",
    0=> "Não passou codigo",
    default => "not valid"
};