<?php

/*if elseif else*/
/* A - Alimenticios B- Vestuiario C-Limpeza*/ 
/* objetivo: receber o codigo e receber a categoria selecionada */

$codigo = $_GET['codigo'] ?? '';
if($codigo == "A" or $codigo == "a" or $codigo == 1){
    echo "produtos Alimenticios <br>";
}elseif($codigo == "B" or $codigo == "b"){
    echo"Produtos de vestuarios <br>";
}elseif($codigo == "C" or $codigo == "c"){
    echo"Produtos de limpeza <br>";
}else{
    echo"código inválido <br>";
}


echo "<hr>";


switch($codigo){
    case "A":
    case "a":
    case 1:
        echo"Produtos Alimenticios <br>";
    break;
    case "B":
    case "b":
        echo"Produtos de vestuario <br>";
    break;
    case "C":
    case "c":    
        echo"Produtos de limpeza <br>";
    break;
    default:
        echo "Codigo inválido <br>";
}

echo "<hr>";

$resultado = match ($codigo) {
     "A","a", '1' =>"produtos alimenticios",
     "B","b"=>"produtos de vestuario",
     "C","c"=>"produtos de limpeza",
     default => "código inválido"
};

echo"$resultado";