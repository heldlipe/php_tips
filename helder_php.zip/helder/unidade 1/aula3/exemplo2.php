<?php
  
  $valor = 10;
  $valor = 15 ;

  #constantes
  define('TAXA1', 1.5); #não usa cifrão e geralmente em maiusculas.
  echo TAXA1; 
 $total = $valor * TAXA1;
 echo "<h2>$total</h2>";

 const TAXA2 = 1.8;
?>