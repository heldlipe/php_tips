<?php
#conversão !IMplicita! de dados

$a = "10";
$b = "115a";

$total = $a + $b; #soma impliicta com a conversão implicita
$result = $a.$b; # concatenação "  .   "   
echo $total; 
echo "<hr>";
echo $result;

#$total = 125a



 #conversão !EXplicita! de dados

 $c = (int) 10.8;
 $d = (int) 8.2;
   
$TOTAL = $c + $d ;
 echo "<hr>$TOTAL</hr>" ;
?>