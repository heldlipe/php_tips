<?php

$nome = "Helder Felipe" ;
const NUMERO = 10;
$servidor = true ; 
$result = $servidor ? "sim" : "não"; 
$idade = 19;
$salario = 1452.65; 

echo gettype($servidor); 
echo "<hr>";
echo gettype(NUMERO); 
echo "<hr>";
echo gettype($nome); 
echo "<hr>";
echo gettype($result); 
echo "<hr>";
echo gettype($idade); 
echo "<hr>";
echo gettype($salario); 
echo "<hr>";
var_dump($salario);
var_dump($nome);
?>