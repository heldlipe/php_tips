<?php

$frase = "irei verificar o
tipo de dado de uma variavel";
$verdadeira = true;
$falsa = false;
$number = 15;
$decimal = 15.56;
const IDADE = 15;
const NAME = "HELDER" ;

#comando utilizado em processo de debug    que imprime o valor e o tipo da variavel.
var_dump($frase);
var_dump($verdadeira);
var_dump($falsa);
var_dump($number);
var_dump($decimal);
var_dump(IDADE);
var_dump(NAME);

?>