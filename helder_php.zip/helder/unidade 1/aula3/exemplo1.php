<?php 


echo "<h1> Working variables <H1>";

$nome = "Helder Felipe ";
$idade = 19;
$altura = 1.8;
$professor = false;

echo "<h2>$nome</h2>" ; #interpolação
echo'<p>Idade:' .$idade. 'anos</P>'; #concatenação
echo "<p>Altura:" .$altura."cm </p>";
$resposta = $professor ? "sim" : "não";
#operador ternário: verdadeiro ou falso ? verdadeiro : falso;
echo "É professor? $resposta"; 



?>