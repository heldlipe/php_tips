<?php 
    const TAXA3 = 3.1415 ;
    $pi = TAXA3;
    echo "<h2>".TAXA3."</h2>";
    #echo"<h2> $pi </h2>";
?>