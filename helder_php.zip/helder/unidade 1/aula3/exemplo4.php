<?php 
#crie uma vraiavel para cada um dos tipos 
#básicos de dados : int, String, Float, Bool
#crie também uma constante de qualquer tipo.
#imprima todas as variaveis e a constante em tags h1 a h5

$nome = "Helder Felipe" ;
const NUMERO = 10;
$servidor = true ; 
$result = $servidor ? "sim" : "não"; 
$idade = 19;
$salario = 1452.65;

echo "<h1>Seu nome é: $nome </h1>";    
echo'<h2> sua nota é: '.NUMERO.'</h2>'; 
echo  "<h3>Servidor? $result </h3>"; 
echo "<h4>idade:".$idade."</h4>"; 
echo '<h5> seu salario é:R$'.$salario.'</h5> <h1> sua media é:'.NUMERO.'</h1>'; 
 

?>