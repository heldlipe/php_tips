<?php 

    $num1 = $_POST['num1'] ?? 0;
    $num2 = $_POST['num2'] ?? 0;

    if( $num1 > $num2){
        echo "<h2> $num1 é maior que o $num2 </h2>";
    }elseif($num1 == $num2){
        echo "<h2> $num1 é igual que o $num2 </h2>";  
    }else{
        echo "<h2> $num1 é menor que o $num2 </h2>"; 
    }

    

    echo "<h3><a href='exemplo6.php'>adiantar</a></h3>";
    echo "<h3><a href='exemplo4.php'>voltar</a></h3>";