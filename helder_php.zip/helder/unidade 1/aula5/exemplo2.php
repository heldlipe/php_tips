<?php 

    $n1 = $_POST['num1'] ?? 0;
    $n2 = $_POST['num2'] ?? 0;

    echo "<h1> O número 1 é: $n1 | e o número 2 é: $n2 </h1>";

    $soma = $n1 + $n2;
    echo "$n1 + $n2 = $soma <hr>";
    $sub = $n1 - $n2;
    echo "$n1 - $n2 = $sub <hr>";
    $multi = $n1 * $n2;
    echo "$n1 X $n2 = $multi <hr>";
    $div = $n1 / $n2;
    echo "$n1 ÷ $n2 = $div <hr>";
    $resto = $n1 % $n2;
    echo "O resto da divisão é : $resto <hr>";
    $expo = $n1 ** $n2;
    echo "$n1 <sup>$n2</sup> = $expo  <hr>";


    echo "<h3><a href='exemplo1.php'>voltar</a></h3>";
    echo "<h3><a href='exemplo3.php'>adiantar</a></h3>";