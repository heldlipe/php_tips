<?php
#operadores de comparação, 
#toda operação de comparação tem um valor booleano ou seja true o false, 
#toda operação de comparação tem dois operando s e um sinal de comparação


$a = 10;
$b = 5;
$c = 8;
$d = "10";

var_dump( $a == 10 );
echo "<hr>";
var_dump( $a == $d );
echo "<hr>";
var_dump( $a === $d ); #verifica o tipo e conteudo.  identidade, o tipo importa.
echo "<hr>";
var_dump( $a != $b ); #ou <>
echo "<hr>";
var_dump( $a !== $d ); # não identidade, o tipo importa.
echo "<hr>";
var_dump( $a > $b );
echo "<hr>";
var_dump( $a < $b );
echo "<hr>";
var_dump( $a >= $d );
echo "<hr>";
var_dump( $b <= $c );
echo "<hr>";

echo "<h3><a href='exemplo4.php'>adiantar</a></h3>";
echo "<h3><a href='exemplo2.php'>adiantar</a></h3>";