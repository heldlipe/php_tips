<?php

$ano1 = $_POST["ano1"] ?? 0;

if($ano1 <= 2006 ){
    echo"<h2> Maior de idade</h2>";
}else{
    echo"<h2>menor de idade </h2>";
}

echo "<h3><a href='exemplo6.php'>voltar</a></h3>";