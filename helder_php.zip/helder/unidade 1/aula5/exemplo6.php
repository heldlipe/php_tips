<!DOCTYPE html>
<html lang="pt-br">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scal">
    <title> idades</title>
</head>
<body> 
    <h1> datas de nascimento</h1>
    <form action="exemplo7.php" method="post">
        <label>  
            Digite seu ano de nascimento:
            <input type="number" name="ano1">
        </label>
        <button>verificar sua idade</button>
    </form>
</body>