<!DOCTYPE html>
<html lang="pt-br">
<head> 
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scal">
    <title> PHP - aula 5</title>
</head>
<body> 
    <h1> formulario e o PHP</h1>
    <form action="exemplo2.php" method="post">
        <label>  
            Número 1:
            <input type="number" name="num1">
        </label>
        <label>  
            Número 2:
            <input type="number" name="num2">
        </label>
        <button>Calcular</button>
    </form>
</body>
