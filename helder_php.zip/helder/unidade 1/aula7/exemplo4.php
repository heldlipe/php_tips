<?php

$cod = "pooh";

$resultado = match($cod){
    1 => "Em separação no estoque",
    2 => "Na transportadora",
    3 => "Em processo de Entrega",
    4,'pooh' => "Entregue",
    default => "Código Inválido"
};

echo $resultado;