<?php

$statuscod = 400;

switch ($statuscod) {
    case 200:
        $result = "ok";
    break;
    case 300:
        $result = "URL redirecionada";
    break;
    case 400:
    case 404:
        $result = "Recurso não encontrado";
    break;
    case 500:
        $result = "Erro no servidor";
    break;
    default:
        $result = "status code inválido";
    break;
}

echo "$result // ";

$resultado = match($statuscod){
  200 => "ok",
  300 => "URL redirecionada",
  400,404 => "Recurso não encontrado",
  500 => "Erro no servidor",
  default => "status code inválido"
};

echo $resultado;