<?php

$cod = '4';

switch($cod){
    case '1' :
        $resultado = "Em separação no estoque";
    break;
    case '2' :
        $resultado = "Na transportadora";
    break;
    case '3' :
        $resultado = "Em processo de Entrega";
    break;
    case '4' :
        $resultado = "Entregue";
    break;
    default:
        $resultado = "Código Inválido";
    break;
}

echo $resultado;