<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E. controle</title>
</head>
<body>
    <form action="exemplo2.php" method="get">
        <h1>Escolha um</h1>
        <label>
            Numero 1
            <input type="number" name="num1">
        </label>
        <br>
        <label>
            Numero 2
            <input type="number" name="num2">
        </label>
        <br>
        <select name="operacao">
            <option value = ""> </option>
            <option value = "sub">Subtração </option>
            <option value = "soma"> Soma</option>
            <option value = "multi"> Multiplicação</option>
            <option value = "div">Divisão </option>
        </select>
        <br>
        <button>Calcular</button>
    </form>
</body>
</html>