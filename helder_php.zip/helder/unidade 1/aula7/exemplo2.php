<?php

$num1 = $_GET['num1'] ?? 0;
$num2 = $_GET['num2'] ?? 0;
$op = $_GET['operacao'] ?? null;

switch($op){
    case 'soma':
        $resultado = $num1 + $num2;
    break;
    case 'sub':
        $resultado = $num1 - $num2;
    break;
    case 'multi':
        $resultado = $num1 * $num2;
    break;
    case 'div':
        $resultado = $num1 / $num2;
    break;
    default:
        $resultado = "operação inválida";
    break;
}

echo $resultado;